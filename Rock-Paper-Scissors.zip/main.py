import random, time

CompWinList = []
UserWinList = []

print("Welcome to Rock Paper Scissors!")
print()
time.sleep(1)
print(" ROCK 🗿 ")
print()
time.sleep(1.5)
print(" PAPER 🧾 ")
print()
time.sleep(1.5)
print(" SCISSORS ✂️ ")
print()
time.sleep(1.5)

print()
print()
print("There is an unlimited number of rounds but the program will keep track of your win record as you play.")
print()
time.sleep(2)
print("The game starts in 3 seconds.")
time.sleep(3)

def RoundSimulation():

  Options = [" ROCK 🗿 ", " PAPER 🧾 ", " SCISSORS ✂️ "]
  ComputerChoice = random.choice(Options)
  i = 0

  print()
  print("--------------------------------------------------")
  print()
  YourChoice = input("What's your choice? (R / P / S) : ")
  print()
  if YourChoice.upper() == "R":
    print("You chose ROCK!")
    FinalUserChoice = " ROCK 🗿 "
  elif YourChoice.upper() == "P":
    print("You chose PAPER!")
    FinalUserChoice = " PAPER 🧾 "
  elif YourChoice.upper() == "S":
    print("You chose SCISSORS!")
    FinalUserChoice = " SCISSORS ✂️ "

  print()
  print("Rock...")
  time.sleep(1)
  print()
  print("Paper...")
  time.sleep(1)
  print()
  print("Scissors...")
  time.sleep(1)
  print()
  print("🔫  SHOOT 🔫")
  time.sleep(0.5)
  print()

  print("     You chose:  " + FinalUserChoice + "     The computer chose: " + ComputerChoice )
  print()

  if ComputerChoice == " ROCK 🗿 " and FinalUserChoice == " SCISSORS ✂️ ":
    print("Rock beats Scissors!")
    print()
    print("Computer wins...")
    CompWinList.append("L")
  elif FinalUserChoice == " ROCK 🗿 " and ComputerChoice == " SCISSORS ✂️ ":
    print("Rock beats Scissors!")
    print()
    print("User wins!!!")
    UserWinList.append("W")
  elif ComputerChoice == " SCISSORS ✂️ " and FinalUserChoice == " PAPER 🧾 ":
    print("Scissors beats Paper!")
    print()
    print("Computer wins...")
    CompWinList.append("L")
  elif FinalUserChoice == " SCISSORS ✂️ " and ComputerChoice == " PAPER 🧾 ":
    print("Scissors beats Paper!")
    print()
    print("User wins!!!")
    UserWinList.append("W")
  elif ComputerChoice == " PAPER 🧾 " and FinalUserChoice == " ROCK 🗿 ":
    print("Paper beats Rock!")
    print()
    print("Computer wins...")
    CompWinList.append("L")
  elif FinalUserChoice == " PAPER 🧾 " and ComputerChoice == " ROCK 🗿 ":
    print("Paper beats Rock!")
    print()
    print("User wins!!!")
    UserWinList.append("W")
  elif FinalUserChoice == ComputerChoice:
    print("You both chose " + FinalUserChoice)
    print()

  UserWinValue = len(UserWinList)
  CompWinValue = len(CompWinList)
  print(" - - - - - - - - ")
  print()
  print("You have " + str(UserWinValue) + " wins and the computer has " + str(CompWinValue))
  print()
  if (CompWinValue + UserWinValue) > 0:
    print("Your win percentage is " + str((UserWinValue / (UserWinValue + CompWinValue))*100) + "%.")

i = 2
while i == 2:
  RoundSimulation()
  time.sleep(5)


